#include "datetime.hpp"

const char DateTime::DayName[7][10] PROGMEM =
{
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday",
};
