#include "rtc.hpp"

RTC rtc = RTC();
