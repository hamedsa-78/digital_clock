#include "beeper.hpp"

Beeper beeper = Beeper();
