#include "alarm.hpp"

AlarmManager alarm_manager = AlarmManager();
