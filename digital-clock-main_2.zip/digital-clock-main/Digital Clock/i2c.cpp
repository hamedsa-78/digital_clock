#include "i2c.hpp"

I2c i2c = I2c();
