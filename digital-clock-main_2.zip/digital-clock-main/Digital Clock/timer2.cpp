#include "timer2.hpp"

Timer2 timer2 = Timer2();
